En la carpeta src se encuentran los códigos, el programa principal se encuentra en Main
El programa lee las jugadas desde el archivo "jugadas.txt" e imprime el estado del juego cada vez que lee una jugada
Las jugadas que se encuentran en archivo "jugadas.txt" son las del ejemplo del enunciado de la tarea.
El equipo 1 es el local
El equipo 2 es el equipo visitante por lo que es el primer equipo bateando.